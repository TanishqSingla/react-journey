import React from "react";

function Details(props) {
  return <p className="info">{props.info}</p>;
}

export default Details;
